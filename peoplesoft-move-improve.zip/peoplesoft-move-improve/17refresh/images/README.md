Add all images used in this tutorial to this folder.
